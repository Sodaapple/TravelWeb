﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab_View_Razor.Models {
    public class Student {
        public int Id;
        public string Name;
        public int Score;
        public string ClassName;
    }
}
